from django.apps import AppConfig


class PoisenseappConfig(AppConfig):
    name = 'poisenseapp'
